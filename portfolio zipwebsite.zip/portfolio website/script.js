function scrollToSection() {
  document.getElementById("contact").scrollIntoView({
    behavior: "smooth"
  });
}
